/*
 * HTMLCleaner.java
 *
 * This class is used for stripping away boiler-plate code from webpages that
 * would add noise to the collected corpus.
 *
 * Of course, it doesn't do any thing yet!
 */

package drayson.weboca;

/**
 *
 * @author Andy Roberts
 */
public class HTMLCleaner {
    
    /** Creates a new instance of HTMLCleaner */
    private HTMLCleaner() {
    }
    
}
