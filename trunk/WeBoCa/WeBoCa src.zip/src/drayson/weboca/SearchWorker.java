/*
 * SearchWorker.java
 *
 * Created on 12 August 2006, 21:13
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package drayson.weboca;

import javax.swing.DefaultListModel;
import org.jdesktop.swingworker.SwingWorker;

/**
 *
 * @author Andy Roberts
 */
public class SearchWorker extends SwingWorker {
    
    /** Creates a new instance of SearchWorker */
    public SearchWorker(String tupleString, DefaultListModel model) {
    }

    protected Object doInBackground() throws Exception {
        return null;
    }
    
}
